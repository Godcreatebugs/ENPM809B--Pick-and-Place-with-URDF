ENPM 809B===[ Group-1 ]
Members:
1. Prasanna Marudhu(116197700)
2. Abhiram Dapke(116237024)
3. Smriti Gupta(116748612)
4. Niket Shah (116345156)
5. Piyushkumar Bhuva(116327473)



Contents:
Folder (group1_rwa2)
   - config
   - include
   - launch
   - src
   - CMakeLists.txt
   - package.xml


HOW TO RUN
1. Put the package(group1_rwa2) in your catkin_ws folder.
2. Build the package "group1_rwa2" using catkin_make.
3. Launch the gazebo environment using "roslaunch group1_rwa2 sample_environment.launch".
4. Run the cpp file in root directory using command "rosrun group1_rwa2 ariac_example_node ".



====>>>You can see the output pose for 6 gasket components on the bin(from logical camera 1) and 9 piston rod components(from logical camera 4) in the terminal window.  
